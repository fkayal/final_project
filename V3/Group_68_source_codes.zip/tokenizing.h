// This is the safegaurded header file of Tokeniznig module of Final Project 
#ifndef _TOKENIZING_H 
#define _TOKENIZING_H

#include <stdio.h> //this is to include the standard input output header file
#include <string.h> //this is to include the string library
void tokenizing(); //this is the function prototype for the function tokenizing
#endif // !
