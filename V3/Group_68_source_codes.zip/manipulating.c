
//To overcome the strcat warnings in the code
#define _CRT_SECURE_NO_WARNINGS
//Including the Header file
#include "manipulating.h"

//Defining the function "manipulating", which concatenats two strings
void manipulating() {


	/*VERSION 3*/
	printf("*** Start of Searching Strings Demo ***\n");

	//declaring a varaiable 'big_string' of type char which can store 79 characters.
	char big_string[80];

	//declaring a varaiable 'sub_string' of type char which can store 79 characters.
	char sub_string[80];

	//declaring a pointer 'address' of type char
	char* address;
	printf("Type the big string (q - to quit):\n");

	//Gets the input from the user and store it into "big_string".
	gets(big_string);

	// prompt user until 'big_string' is other than q
	while (strcmp(big_string, "q") != 0) {
		printf("Type the substring:\n");

		//Gets the input from the user and store it into "sub_string".
		gets(sub_string);

		//this will search strings "big_string" and "sub_string" and give value to the result
		address = strstr(big_string, sub_string);

		//condition to check if address is not equal to NULL
		if (address != NULL)
			printf("Found at %ld position\n", (long)address - (long)big_string);
		else
				printf("Not found\n");

		printf("Type the big string (q - to quit):\n");

		//Gets the input from the user and store it into "big_string".
		gets(big_string);
	}

	printf("*** End of Searching Strings Demo ***\n\n");

}