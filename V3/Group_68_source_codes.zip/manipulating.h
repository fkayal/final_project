//Safeguarding the header file
#ifndef _MANIPULATING_H
#define _MANIPULATING_H

//including the header files
#include <stdio.h>
#include <string.h>

//function prototype is declared 
void manipulating();

#endif
