#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80
#include "converting.h"



/* Version 1
 */
// CONVERTING MODULE SOURCE
int main(void) {
	converting();
    
}
	void converting(void) {
		printf("*** Start of Converting Strings to int Demo ***\n");
		char intString[BUFFER_SIZE];	//create virable to storage user input
		int  intNumber;  //creat virable to output the result
		do {
			printf("Type an int numeric string (q - to quit):\n");
			fgets(intString, BUFFER_SIZE, stdin);	//get user input
			intString[strlen(intString) - 1] = '\0';	//make sure char string end with '\0'
			if (strcmp(intString, "q") != 0) {	//compare two string,when string not equal to "q" transfer the char to int             
                
				intNumber = atoi(intString);	//transfer char to int, if the result is invalid return 0
                
				printf("Converted number is %d\n", intNumber);	//print out the result
			}
		} while (strcmp(intString, "q") != 0); // do the transfer until string equal to "q"
				printf("*** End of Converting Strings to int Demo ***\n\n");
    }