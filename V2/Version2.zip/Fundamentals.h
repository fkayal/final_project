#define _CRT_SECURE_NO_WARNINGS												
#include "fundamentals.h"													



void fundamentals() {																				
	char buffer1[80];														
	char num_input[10];														
	unsigned int position;													
	printf("Type not empty string (q - to quit):\n");
	printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");
	gets(buffer1);															
	while (strcmp(buffer1, "q") != 0) {										
		gets(num_input);													
		position = atoi(num_input);											
		if (position >= strlen(buffer1)) {									
			position = strlen(buffer1) - 1;									
			printf("Too big... Position reduced to max. available\n");
		}
		printf("The character found at %d position is \'%c\'\n", position, buffer1[position]);		
		printf("Type not empty string (q - to quit):\n");
		printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");
		gets(buffer1);																				


						
	char buffer2[80];													
	printf("Type a string (q - to quit):\n");
	gets(buffer2);															
	while (strcmp(buffer2, "q") != 0) {										
		printf("The length is %lu\n", strlen(buffer2));						
		printf("Type a string (q - to quit):\n");
		gets(buffer2);														
	}					
}